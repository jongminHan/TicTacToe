var searchData=
[
  ['screen_5fheight_115',['SCREEN_HEIGHT',['../_d_e_f_i_n_i_t_i_o_n_s_8h.html#ab454541ae58bcf6555e8d723b1eb95e7',1,'DEFINITIONS.h']]],
  ['scrren_5fwidth_116',['SCRREN_WIDTH',['../_d_e_f_i_n_i_t_i_o_n_s_8h.html#ac1f1ee6e667daef0f46898d04032c94e',1,'DEFINITIONS.h']]],
  ['splash_5fstate_5fshow_5ftime_117',['SPLASH_STATE_SHOW_TIME',['../_d_e_f_i_n_i_t_i_o_n_s_8h.html#a7b6ab4c16624aec7fbadcc8a4d183ae1',1,'DEFINITIONS.h']]]
];
