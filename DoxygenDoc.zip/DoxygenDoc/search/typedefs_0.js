var searchData=
[
  ['gamedataref_119',['GameDataRef',['../namespacelecture.html#a23916db63f90a66c242748e6f7f93280',1,'lecture']]]
];
