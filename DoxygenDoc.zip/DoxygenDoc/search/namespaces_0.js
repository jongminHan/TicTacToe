var searchData=
[
  ['lecture_66',['lecture',['../namespacelecture.html',1,'']]]
];
