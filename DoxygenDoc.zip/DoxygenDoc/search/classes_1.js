var searchData=
[
  ['game_59',['Game',['../classlecture_1_1_game.html',1,'lecture']]],
  ['gamedata_60',['GameData',['../structlecture_1_1_game_data.html',1,'lecture']]]
];
