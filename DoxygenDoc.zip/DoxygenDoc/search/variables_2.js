var searchData=
[
  ['machine_114',['machine',['../structlecture_1_1_game_data.html#ab758e19e9cc34b5c377b68ee4f27c780',1,'lecture::GameData']]]
];
