var searchData=
[
  ['window_51',['window',['../structlecture_1_1_game_data.html#ac2d68d1d96e7c369960144442750e564',1,'lecture::GameData']]]
];
